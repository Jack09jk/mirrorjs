npm install && ./aria.sh && npm start
